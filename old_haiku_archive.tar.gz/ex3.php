<?php
$handle = fopen("archive/0001.html", "r");
$pattern1 = '/body=/';
$pattern2 = '/Date:/';
if ($handle) {
    while (!feof($handle)) {
        $line[] = fgets($handle, 1024);
        if ($dummy = preg_grep($pattern1, $line)) {
            array_push($matches, $line);
        }
        $matches = preg_grep($pattern1, $line);
    }
    fclose($handle);
}
print_r($matches);
?>
