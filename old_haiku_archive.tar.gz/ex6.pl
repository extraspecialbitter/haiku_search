#!/usr/bin/perl

# Initializations

use File::Find;
@dirs = ("archive_1999", "archive_2000", "archive_2001", "archive_2002", "archive_2003", "archive_2004", "archive_2005","archive_2006", "archive_2007", "archive_2008", "archive_2009", "archive_2010");
# find sub { $sum += -s }, @dirs;
my $filedir="./archive";
$filename="$filedir/0022.html";
$results="results.html";
$scratch="tempfile.html";
$number_of_lines=`wc -l $filename | cut -d' ' -f1`;
$search_string1="body=";
$search_string2="<pre>";
$search_string3="dog";
$toggle=0;

# Do this for every archive HTML file



# Open the input file and copy each line into an array

open(INFILE,$filename);
open(TMPFILE, "> $scratch");
# open(OUTFILE, "> $results");

while (<INFILE>) {
     $line = $_;
     last if $. == $line_count;
     push (@text, $line);
}

# Read haiku lines into temporary buffer

$line_index=0;
$scratch_index=0;

while ($line_index < $number_of_lines)
{
    $_ = @text[$line_index];
    if (/$search_string1/)
    {
        if ($toggle == 0)
        {
            print TMPFILE @text[$line_index];
            $toggle=1;
            $scratch_index=$scratch_index + 1;
        }
        else {
            $toggle=2;
        }
    }
    elsif ($toggle == 1)
    {
        if (! /$search_string2/)
        {
            if (! /$search_string1/)
            {
                print TMPFILE @text[$line_index];
                $scratch_index=$scratch_index + 1;
            }
        }
        else {
            $toggle=2;
        }

    }
    $line_index=$line_index + 1;

}

close(TMPFILE);
close(INFILE);

# Search temporary buffer for search string

open(INFILE,$scratch);

while (<INFILE>) {
     $line = $_;
     last if $. == $line_count;
     push (@text, $line);
}

$number_of_lines=`wc -l $scratch | cut -d' ' -f1`;
$line_index=0;
$results_index=0;
$scratch_index=0;
$found=0;

while ($scratch_index < $number_of_lines)
{
    $_ = @text[$line_index];
    if (/$search_string3/)
    {
        $toggle=1;
    }
    else 
    {
        $scratch_index=$scratch_index + 1;
    }
}

close(INFILE);
# close(OUTFILE);
