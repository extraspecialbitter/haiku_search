#!/usr/bin/perl

# Initializations

$filedir="./archive";
$filename="$filedir/0022.html";
$results="results.html";
$number_of_lines=`wc -l $filename | cut -d' ' -f1`;
$search_string1="body=";
$search_string2="<pre>";
$toggle=0;

# Open the input file and copy each line into an array

open(INFILE,$filename);
open(OUTFILE, "> $results");


while (<INFILE>) {
     $line = $_;
     last if $. == $line_count;
     push (@text, $line);
}

# Do this for each line

$line_index=0;
$results_index=0;

while ($line_index < $number_of_lines)
{
    $_ = @text[$line_index];
    if (/$search_string1/)
    {
        if ($toggle == 0)
        {
            print OUTFILE @text[$line_index];
            $toggle=1;
            $results_index=$results_index + 1;
        }
        else {
            $toggle=2;
        }
    }
    elsif ($toggle == 1)
    {
        if (! /$search_string2/)
        {
            if (! /$search_string1/)
            {
                print OUTFILE @text[$line_index];
                $results_index=$results_index + 1;
            }
        }
        else {
            $toggle=2;
        }

    }
    $line_index=$line_index + 1;

}

close(OUTFILE);
