#!/bin/bash

# Global Initializations

RESULTS="results.txt"
TEMP="tempfile.txt"
SEARCH_STRING0="deleted"
SEARCH_STRING1="body="
SEARCH_STRING2="<pre>"
SEARCH_STRING3="<p>="
SEARCH_STRING4="<br>"
SEARCH_STRING5="<p>"

rm -f $RESULTS
rm -f $TEMP
touch $RESULTS
touch $TEMP

# Refresh this year's archive

ssh mena@sasi.pair.com "/usr/home/mena/bin/archive_update.ksh"
rsync -lat --delete -e ssh mena@sasi.pair.com:/usr/www/users/mena/haikupoet/archive/ ~/haiku_search/archive/

# Do this for every archive HTML file

for ARCHIVE in `find archive_* -name "[0-9][0-9][0-9][0-9].html"`
do

# Initialize for each file

   LINE_INDEX=1
   SCRATCH_INDEX=0
   NUMBER_OF_LINES=`wc -l $ARCHIVE | cut -d' ' -f1`
   TOGGLE=0

# Open the input file and start processing

   while [ $LINE_INDEX -lt  $NUMBER_OF_LINES ]
   do
      LINE=`tail -${NUMBER_OF_LINES} $ARCHIVE | head -1`
      if [ `echo $LINE | grep -c $SEARCH_STRING1` -eq 1 ];
      then
         if [ $TOGGLE -eq 0 ];
         then
            TOGGLE=1
         else
            TOGGLE=2
         fi
      elif [ $TOGGLE -eq 1 ];
      then
         if [ `echo $LINE | grep -c $SEARCH_STRING0` -eq 1 ];
         then
            cat /dev/null > $TEMP
            TOGGLE=2
         elif [ `echo $LINE | grep -c $SEARCH_STRING2` -eq 0 ];
         then
            if [ `echo $LINE | grep -c $SEARCH_STRING3` -eq 1 ];
            then
               TOGGLE=2
            elif [ `echo $LINE | grep -c $SEARCH_STRING4` -eq 0 ];
            then
               echo -n "${LINE}<br>" >> $TEMP
            fi
         else
             TOGGLE=2
         fi
      fi
      NUMBER_OF_LINES=`expr $NUMBER_OF_LINES - 1`
      
   done
   echo "" >> $TEMP

# Copy the processed HTML file into the CSV file
 
   cat $TEMP >> $RESULTS
   cat /dev/null > $TEMP

done

# Post processing

sed -i 's/^<p>//' $RESULTS
sed -i 's/&nbsp;//g' $RESULTS
sed -i 's/<p>_.*//g' $RESULTS
sed -i 's/<br>===.*//g' $RESULTS
sed -i 's/Fidelity.*//g' $RESULTS
sed -i 's/FeB.*//g' $RESULTS
sed -i 's/<a href.*//g' $RESULTS
sed -i 's/----.*//g' $RESULTS
sed -i 's/____.*//g' $RESULTS

scp $RESULTS mena@sasi.pair.com:/usr/www/users/mena/haikupoet/archive.txt
