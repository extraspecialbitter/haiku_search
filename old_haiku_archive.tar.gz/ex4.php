<?php
$infile = fopen("archive/0001.html", "r");
$outfile = fopen("results.html", "rw");
$pattern = '/body=/';
if ($infile) {
    while (!feof($infile)) {
        $line[] = fgets($infile, 1024);
        $dummy = preg_grep($pattern, $line);
        $body_count = count($dummy);
        if ($body_count == 1) {
            $match = current($line);
            print ($match);
            fwrite($outfile, $match);
            $match = next($line);
        }
        $match = next($line);
    }
    fclose($infile);
    fclose($outfile);
}
?>
