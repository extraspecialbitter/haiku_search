#!/bin/sh

if [ $# -ne 1 ];
then
   echo "Usage: $0 <string>"
   exit 1
fi

SEARCH_STRING=$1
DIR=~/tmp
OUTFILE=${DIR}/results.html
TMPFILE=${DIR}/tmpfile.txt
ARCHIVE=${DIR}/archive.csv

rm -f ${OUTFILE}

echo "<html>" >> $OUTFILE
echo "<body>" >> $OUTFILE

# Initialize line counter

LINE_INDEX=1
NUMBER_OF_LINES=`wc -l $ARCHIVE | cut -d' ' -f1`

# Open the input file and start processing

while [ $LINE_INDEX -lt  $NUMBER_OF_LINES ]
do
  LINE=`tail -${NUMBER_OF_LINES} $ARCHIVE | head -1`
  echo $LINE > $TMPFILE
  if [ `grep -c ${SEARCH_STRING} ${TMPFILE}` -eq 1 ];
  then
     sed -i -e "s/,/<br>/g" $TMPFILE
     echo "<br>" >> $TMPFILE
     cat $TMPFILE
  fi
  NUMBER_OF_LINES=`expr $NUMBER_OF_LINES - 1`
done >> $OUTFILE

echo "</body>" >> $OUTFILE
echo "</html>" >> $OUTFILE

# Copy the results to the website

scp ${OUTFILE} mena@sasi.pair.com:/usr/www/users/mena/haikupoet/
