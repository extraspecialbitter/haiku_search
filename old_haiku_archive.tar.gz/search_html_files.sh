#!/bin/sh

if [ $# -ne 1 ];
then
   echo "Usage: $0 <string>"
   exit 1
fi

STRING=$1
OUTDIR=~/haiku_search
OUTFILE=${OUTDIR}/results.html

rm -f ${OUTFILE}

echo "<html>" >> $OUTFILE
echo "<body>" >> $OUTFILE

for i in `find archive* -type d -print`
do
  k=`echo $i | cut -d'/' -f1`
  if [ $k = "archive" ];
  then
    YEAR=2011
  else
    YEAR=`echo $k | cut -d'_' -f2`
  fi
  echo "<h2>${YEAR}</h2>" >> $OUTFILE
  for j in `grep -i ${STRING} ${i}/[01]???.html | cut -d':' -f1 | uniq`
  do
    echo "<a href=./"${j}">"${j}"</a><br>"
  done
done >> $OUTFILE

echo "</body>" >> $OUTFILE
echo "</html>" >> $OUTFILE
