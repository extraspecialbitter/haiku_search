<?php
$handle = fopen("archive/0001.html", "r");
$pattern = '/Date:/';
if ($handle) {
    while (!feof($handle)) {
        $line[] = fgets($handle, 1024);
        $matches = preg_grep($pattern, $line);
    }
    fclose($handle);
}
print_r($matches);
?>
